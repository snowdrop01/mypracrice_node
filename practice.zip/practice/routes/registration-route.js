var express = require('express');
var router = express.Router();
var db = require('../database');

// to display registration form 
router.get('/', function (req, res, next) {

    // console.log("inside regerstre")
    res.render('registration-form');
});

// to store user input detail on post request
router.post('/', function (req, res, next) {

    inputData = {
        name: req.body.name,
        email_address: req.body.email_address,
        phone_no: req.body.phone_no,
        password: req.body.password,
        confirm_password: req.body.confirm_password,
        dob: req.body.dob,
        address: req.body.address,
        country: req.body.country,
        role: req.body.role
    }
    // check unique email address
    var sql = 'SELECT * FROM registration WHERE email_address =?';
    db.query(sql, [inputData.email_address], function (err, data, fields) {
        if (err) throw err
        if (data.length > 1) {
            var msg = inputData.email_address + "was already exist";
        } else if (inputData.confirm_password != inputData.password) {
            var msg = "Password & Confirm Password is not Matched";
        } else {

            // save users data into database
            var sql = 'INSERT INTO registration SET ?';
            db.query(sql, inputData, function (err, data) {
                if (err) throw err;
            });
            var msg = "Your are successfully registered";
        }
        res.render('registration-form', { alertMsg: msg });
    })

});
module.exports = router;